package medicaldatabase;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Importdb database = new Importdb();
                
                Importdb.clearDb();
                //Importdb.createAccount("patient", "username", "password");
                //Importdb.createAccount("doctor", "doctor1", "password");
               // Importdb.makeAppointment("d1", "p0", "test", "09/13/13");
		//Importdb.createAccount("patient", "", "");
                //Importdb.createAccount("patient", "", "");
                //Importdb.createAccount("patient", "", "");
               // Importdb.createAccount("doctor", "", "");
		//Importdb.createAccount("doctor", "", "");
               // Importdb.createAccount("doctor", "", "");
               // Importdb.createAccount("doctor", "", "");
		
		//Importdb.setDoctorProfile("d203", "dasd", "hospital", "specialization", "gender");
		
		//Importdb.getUserInfo("d203");
		
		//Importdb.makeAppointment("1", "d3", "p1", "reason", "date");
		
	}

}
